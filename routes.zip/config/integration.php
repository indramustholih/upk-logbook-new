<?php

return [
        'opd' => [
            'url' => env('OPD_URL'),
            'user-agent' => env('OPD_USER_AGENT'),
            'access-key' => env('OPD_ACCESS_KEY'),
        ],
];
