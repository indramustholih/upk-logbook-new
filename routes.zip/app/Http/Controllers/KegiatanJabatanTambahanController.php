<?php

namespace App\Http\Controllers;

use App\Models\KegiatanJabatanTambahan;
use Illuminate\Http\Request;

class KegiatanJabatanTambahanController extends Controller
{
    public function __construct(){
        $this->middleware("auth");
    }

    public function index()
    {
        return view('master.kegiatan-jabatan-tambahan.index');
    }

    public function listData()
    {
        $kegiatan_tambahan = KegiatanJabatanTambahan::select(
            'kegiatan_jabatan_tambahans.nama_kegiatan',
            'kegiatan_jabatan_tambahans.angka_kredit',
            'kegiatan_jabatan_tambahans.output',
            'kegiatan_jabatan_tambahans.satuan',
            'kegiatan_jabatan_tambahans.mutu',
            'kegiatan_jabatan_tambahans.waktu',
            'kegiatan_jabatan_tambahans.biaya'
        )->orderBy('kegiatan_jabatan_tambahans.nama_kegiatan', 'asc')->get();
        $no = 0;
        $data = array();

        foreach ($kegiatan_tambahan as $list) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $list->nama_kegiatan;
            $row[] = $list->angka_kredit;
            $row[] = $list->output;
            $row[] = $list->satuan;
            $row[] = $list->mutu;
            $row[] = $list->waktu;
            $row[] = $list->biaya;
            $row[] = '<div class = "btn-group">
                <a onclick = "editForm(' . $list->id_kegiatan_jabatan_tambahan . ')" class = "btn btn-primary btn-sm" >
                    <i class = "fa fa-pencil"></i>
                </a>
                <a onclick = "deleteData(' . $list->id_kegiatan_jabatan_tambahan . ')" class = "btn btn-danger btn-sm" >
                    <i class = "fa fa-trash"></i>
                </a>
            </div>';
            $data[] = $row;
        }
        $output = array("data" => $data);
        return response()->json($output);
    }
    
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $kegiatan_tambahan = new KegiatanJabatanTambahan();
        $kegiatan_tambahan->nama_kegiatan = $request['nama_kegiatan'];
        $kegiatan_tambahan->angka_kredit = $request['angka_kredit'];
        $kegiatan_tambahan->output = $request['output'];
        $kegiatan_tambahan->satuan = $request['satuan'];
        $kegiatan_tambahan->mutu = $request['mutu'];
        $kegiatan_tambahan->waktu = $request['waktu'];
        $kegiatan_tambahan->biaya = $request['biaya'];
        $kegiatan_tambahan->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
