<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MasterKegiatan extends Model
{
    protected $table ='master_kegiatans';
    protected $primaryKey = 'id_master_kegiatan';
    
}
